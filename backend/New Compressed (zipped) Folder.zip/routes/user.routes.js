const express = require("express");

const userRouter = express.Router();



module.exports = {
    userRouter,
} ;
